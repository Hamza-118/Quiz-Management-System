-- MySQL dump 10.13  Distrib 5.7.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: quizApplication
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question` (
  `id` varchar(30) DEFAULT NULL,
  `name` varchar(500) DEFAULT NULL,
  `opt1` varchar(500) DEFAULT NULL,
  `opt2` varchar(500) DEFAULT NULL,
  `opt3` varchar(500) DEFAULT NULL,
  `opt4` varchar(500) DEFAULT NULL,
  `answer` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES ('1','Which is the highest waterfall in the world?','Denmark strait cataract','Angels falls','Tugela falls','yosemite','Denmark strait cataract');
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `rollNo` varchar(50) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `fatherName` varchar(100) DEFAULT NULL,
  `motherName` varchar(100) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `contactNo` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `tenthInstitutionName` varchar(200) DEFAULT NULL,
  `tenthPercentage` varchar(50) DEFAULT NULL,
  `tenthPassoutYear` varchar(50) DEFAULT NULL,
  `twelveInstitutionName` varchar(200) DEFAULT NULL,
  `twelvePercentage` varchar(50) DEFAULT NULL,
  `twelvePassoutYear` varchar(50) DEFAULT NULL,
  `graduationInstitutionName` varchar(200) DEFAULT NULL,
  `graduationPercentage` varchar(50) DEFAULT NULL,
  `graduationPassoutYear` varchar(50) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `marks` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES ('CSC-20S-075','Hamza Khan','Sohail Ahmed Khan','xyz','Male','03181026118','hamzahmed514@gmail.com','Public School Hyd','77','2017','F.G. Inter Boys College Karachi Cantt','64','2019','Sindh Madressatul Islam University Karachi','Persuing','Persuing','Lotus Street, Karachi',0),('CSC-20S-075','Hamza Khan','Sohail Ahmed khan','xyz','Male','0318-1026118','hamzahmed514@gmail.com','Public School Hyderabad','77 %','2017','F.G. Inter Boys College Karachi, Cantt.','64 %','2019','Sindh Madressatul Islam University Karachi','Persuing','Persuing','House no. LR 8/45, Lotus Street Karachi.',0),('CSC-20S-075','','','','Male','','','Enter Institution name','Enter Percentage','Enter Passout Year','Enter Institution name','Enter Percentage','Enter Passout Year','Enter Institution name','Enter Percentage','Enter Passout Year','',0),('','','','','Male','','','Enter Institution name','Enter Percentage','Enter Passout Year','Enter Institution name','Enter Percentage','Enter Passout Year','Enter Institution name','Enter Percentage','Enter Passout Year','',0);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-07 10:56:32
